<?php

Use App\Models\Core\Propphoto;
use Illuminate\Support\Facades\Http;

$photos = Propphoto::with([
    'theMeta' => function ($query) {
        $query->select('propflyer_id', 'zipDir', 'mlsDir');
    }
])
->whereDate('photoDate', '>=', '2026-05-01')
->take(10)
->get();

$uploaded = 0;
$downloaded = 0;
$missing = 0;
$ok = 0;

foreach ($photos as $photo) {

    // Build local path
    $localPath = public_path(
        "hqphotos/{$photo->theMeta->zipDir}/{$photo->theMeta->mlsDir}/{$photo->photoName}"
    );

    // Build remote URL
    $remoteUrl = "https://realtyemails.com/hqphotos/{$photo->theMeta->zipDir}/{$photo->theMeta->mlsDir}/{$photo->photoName}";

    $localFound = file_exists($localPath);
    $remoteFound = Http::head($remoteUrl)->successful();

    echo "{$photo->propflyer_id} - {$photo->photoName} : ";

    if ($localFound && $remoteFound) {

        echo "OK<br>";
        $ok++;

    } elseif ($localFound && !$remoteFound) {

        echo "Uploading...<br>";
        $result=include('upload.php');
        if($result){
            $uploaded++;
        } else {
            echo "Upload failed for {$photo->photoName}<br>";
        }   

    } elseif (!$localFound && $remoteFound) {

        echo "Downloading...<br>";
        $result=include('download.php');
        if($result){
            $downloaded++;
        } else {
            echo "Download failed for {$photo->photoName}<br>";
        }

    } else {

        echo "Missing on both<br>";
        $missing++;

    }

}

echo "OK: $ok<br>";
echo "Uploaded: $uploaded<br>";
echo "Downloaded: $downloaded<br>";
echo "Missing: $missing<br>";